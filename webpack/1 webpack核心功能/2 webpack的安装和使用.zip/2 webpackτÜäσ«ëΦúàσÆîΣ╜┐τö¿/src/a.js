import $ from "jquery"
 console.log($);
export default 'a';