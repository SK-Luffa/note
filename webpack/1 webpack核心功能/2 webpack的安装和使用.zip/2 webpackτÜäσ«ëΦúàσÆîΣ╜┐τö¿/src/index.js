import a from "./a"
console.log(a);
console.log("hellow,webpack");